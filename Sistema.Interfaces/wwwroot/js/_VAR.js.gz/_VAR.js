var _VAR = {
	idValorRegistroActivo: null,
	dniRelacionadoRegistroActivo: null,
	sexoRelacionadoRegistroActivo: null,
	idUser: null,
	idSucursal: null,
	idCliente: null,
	Username: null,
	p1: null,
	p2: null,
	p3: null,
	ValueforRetrieve:null,
};
